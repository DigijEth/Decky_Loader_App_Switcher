import {
  ButtonItem,
  PanelSection,
  PanelSectionRow,
  staticClasses
} from "@decky/ui";
import { callable, definePlugin } from "@decky/api";
import { useState, useEffect } from "react";
import { FaExchangeAlt } from "react-icons/fa";

interface WindowInfo {
  id: string;
  desktop: string;
  host: string;
  title: string;
}

const switchWindow = callable<[], boolean>("switch_window");
const switchWindowReverse = callable<[], boolean>("switch_window_reverse");
const getWindows = callable<[], WindowInfo[]>("get_windows");
const focusWindow = callable<[window_id: string], boolean>("focus_window");

function Content() {
  const [windows, setWindows] = useState<WindowInfo[]>([]);

  const refreshWindows = async () => {
    const result = await getWindows();
    setWindows(result);
  };

  useEffect(() => {
    refreshWindows();
  }, []);

  return (
    <PanelSection title="Switch Application">
      <PanelSectionRow>
        <ButtonItem layout="below" onClick={() => switchWindow()}>
          Next Window (Alt+Tab)
        </ButtonItem>
      </PanelSectionRow>
      <PanelSectionRow>
        <ButtonItem layout="below" onClick={() => switchWindowReverse()}>
          Previous Window
        </ButtonItem>
      </PanelSectionRow>
      <PanelSectionRow>
        <ButtonItem layout="below" onClick={refreshWindows}>
          Refresh Window List
        </ButtonItem>
      </PanelSectionRow>
      
      {windows.length > 0 && (
        <PanelSection title="Open Windows">
          {windows.map((win) => (
            <PanelSectionRow key={win.id}>
              <ButtonItem
                layout="below"
                onClick={() => focusWindow(win.id)}
              >
                {win.title.length > 30 ? win.title.substring(0, 30) + "..." : win.title}
              </ButtonItem>
            </PanelSectionRow>
          ))}
        </PanelSection>
      )}
    </PanelSection>
  );
}

export default definePlugin(() => {
  console.log("App Switcher plugin loaded");

  return {
    name: "App Switcher",
    titleView: <div className={staticClasses.Title}>App Switcher</div>,
    content: <Content />,
    icon: <FaExchangeAlt />,
    onDismount() {
      console.log("App Switcher unloading");
    },
  };
});
