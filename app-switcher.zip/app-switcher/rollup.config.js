import deckyPlugin from "@decky/rollup";

export default deckyPlugin({
  // Add your extra Rollup options here
})