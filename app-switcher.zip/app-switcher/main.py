import subprocess
import decky

class Plugin:
    async def switch_window(self):
        """Simulate Alt+Tab to switch windows"""
        try:
            subprocess.run(
                ["xdotool", "key", "alt+Tab"],
                env={"DISPLAY": ":0"},
                check=True
            )
            return True
        except Exception as e:
            decky.logger.error(f"Failed to switch window: {e}")
            return False

    async def switch_window_reverse(self):
        """Simulate Alt+Shift+Tab to switch windows in reverse"""
        try:
            subprocess.run(
                ["xdotool", "key", "alt+shift+Tab"],
                env={"DISPLAY": ":0"},
                check=True
            )
            return True
        except Exception as e:
            decky.logger.error(f"Failed to switch window reverse: {e}")
            return False

    async def get_windows(self):
        """Get list of open windows"""
        try:
            result = subprocess.run(
                ["wmctrl", "-l"],
                env={"DISPLAY": ":0"},
                capture_output=True,
                text=True
            )
            windows = []
            for line in result.stdout.strip().split('\n'):
                if line:
                    parts = line.split(None, 3)
                    if len(parts) >= 4:
                        windows.append({
                            "id": parts[0],
                            "desktop": parts[1],
                            "host": parts[2],
                            "title": parts[3]
                        })
            return windows
        except Exception as e:
            decky.logger.error(f"Failed to get windows: {e}")
            return []

    async def focus_window(self, window_id: str):
        """Focus a specific window by ID"""
        try:
            subprocess.run(
                ["wmctrl", "-i", "-a", window_id],
                env={"DISPLAY": ":0"},
                check=True
            )
            return True
        except Exception as e:
            decky.logger.error(f"Failed to focus window {window_id}: {e}")
            return False

    async def _main(self):
        decky.logger.info("App Switcher plugin loaded")

    async def _unload(self):
        decky.logger.info("App Switcher plugin unloaded")
